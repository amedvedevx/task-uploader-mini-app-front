import{aj as oe,r as a,g as I,a as y,k as l,c as t,h as ne,ax as le,aq as de,_ as V,m as $,P as p,ay as ce,az as N,ao as b,aA as E,aB as A,f as K,S as D,i as ue,ag as L,W as q}from"./index-26480508.js";import{S as W,c as ve,M as me,a as ge,b as he}from"./Div-fc2af387.js";const Be=oe("Icon24Chevron","chevron_24","0 0 16 24",'<symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 24" id="chevron_24"><g fill="none" fill-rule="evenodd"><path d="M0 0h16v24H0z" /><path fill="currentColor" d="M4.706 7.706a1 1 0 0 1 0-1.412l.088-.088a.997.997 0 0 1 1.414.002l5.084 5.084a.998.998 0 0 1 0 1.416l-5.084 5.084a1.002 1.002 0 0 1-1.414.002l-.088-.088a.995.995 0 0 1 0-1.412L9 12 4.706 7.706Z" /></g></symbol>',16,24,!1,void 0);var ke=a.createContext({size:0}),pe={stroke:"vkuiImageBaseBadge--background-stroke",shadow:"vkuiImageBaseBadge--background-shadow"},fe=function(e){var i=e.background,s=i===void 0?"shadow":i,r=e.children,o=e.className,n=I(e,["background","children","className"]);return a.createElement("div",y(t({},n),{className:l("vkuiImageBaseBadge",pe[s],o)}),r)},be=function(e){var i=e.className,s=e.theme,r=e.visibility,o=e.children,n=e.onClick,u=I(e,["className","theme","visibility","children","onClick"]),d=ne(),c=le(),g=s??d,v=r??(c?"on-hover":"always");return a.createElement(de,y(t({},u),{type:"button",Component:"button",className:l("vkuiImageBaseOverlay",v==="always"&&"vkuiImageBaseOverlay--visible",g==="light"&&"vkuiImageBaseOverlay--theme-light",g==="dark"&&"vkuiImageBaseOverlay--theme-dark",i),hasHover:v==="on-hover",hoverMode:v==="on-hover"?"vkuiImageBaseOverlay--visible":void 0,focusVisibleMode:"vkuiImageBaseOverlay--focus-visible",hasActive:!1,onClick:n}),o)},U=function(e){var i=e.alt,s=e.crossOrigin,r=e.decoding,o=e.loading,n=e.referrerPolicy,u=e.sizes,d=e.src,c=e.srcSet,g=e.useMap,v=e.getRef,k=e.size,m=k===void 0?24:k,h=e.width,w=e.height,P=e.style,z=e.className,S=e.getRootRef,f=e.withBorder,x=f===void 0?!0:f,B=e.fallbackIcon,R=e.children,J=e["aria-label"],Q=e.onClick,H=e.onLoad,G=e.onError,Y=I(e,["alt","crossOrigin","decoding","loading","referrerPolicy","sizes","src","srcSet","useMap","getRef","size","width","height","style","className","getRootRef","withBorder","fallbackIcon","children","aria-label","onClick","onLoad","onError"]),T=V(a.useState(!1),2),ee=T[0],X=T[1],_=V(a.useState(!1),2),ae=_[0],j=_[1],O=d||c,re=(ae||!O)&&a.isValidElement(B),F=re?B:null,ie=function(M){X(!0),j(!1),H==null||H(M)},te=function(M){X(!1),j(!0),G==null||G(M)},se=function(){switch(m){case 28:return"vkuiImageBase--size-28";case 32:return"vkuiImageBase--size-32";case 40:return"vkuiImageBase--size-40";case 48:return"vkuiImageBase--size-48";case 72:return"vkuiImageBase--size-72"}return null}();return a.createElement(ke.Provider,{value:{size:m}},a.createElement("div",y(t({},Y),{ref:S,style:y(t({},P),{width:m,height:m}),className:l(z,"vkuiImageBase",se,x&&"vkuiImageBase--withBorder",ee&&"vkuiImageBase--loaded"),role:O?"img":"presentation","aria-label":J,onClick:Q}),O&&a.createElement("img",{ref:v,alt:i,className:"vkuiImageBase__img",crossOrigin:s,decoding:r,loading:o,referrerPolicy:n,sizes:u,src:d,srcSet:c,useMap:g,width:h,height:w,onLoad:ie,onError:te}),F&&a.createElement("div",{className:l("vkuiImageBase__fallback")},F),R))};U.Badge=fe;U.Overlay=be;var ye=function(e){var i=e.mode,s=e.size,r=I(e,["mode","size"]),o=s==="large",n=$();if(n===p.IOS)switch(i){case"primary":return o?a.createElement(E,t({level:"2",weight:"2"},r)):a.createElement(E,t({weight:"1",level:"3"},r));case"secondary":return a.createElement(b,t({weight:"1",caps:!0},r));case"tertiary":return a.createElement(E,t({weight:"1",level:"3"},r))}if(n===p.VKCOM)switch(i){case"primary":return o?a.createElement(E,t({level:"2",weight:"1"},r)):a.createElement(A,t({level:"1",weight:"2"},r));case"secondary":return a.createElement(b,t({caps:!0,weight:"1"},r));case"tertiary":return a.createElement(b,r)}switch(i){case"primary":return o?a.createElement(E,t({level:"2",weight:"2"},r)):a.createElement(A,t({weight:"2"},r));case"secondary":return a.createElement(b,t({weight:"1",caps:!0},r));case"tertiary":return a.createElement(A,t({weight:"2"},r))}return null},Re=function(e){var i=e.mode,s=i===void 0?"primary":i,r=e.size,o=r===void 0?"regular":r,n=e.children,u=e.subtitle,d=e.indicator,c=e.aside,g=e.getRootRef,v=e.multiline,k=e.className,m=I(e,["mode","size","children","subtitle","indicator","aside","getRootRef","multiline","className"]),h=$(),w=h===p.VKCOM?W:ve;return a.createElement("header",y(t({},m),{ref:g,className:l("vkuiHeader",h===p.VKCOM&&"vkuiHeader--vkcom",h===p.ANDROID&&"vkuiHeader--android",h===p.IOS&&"vkuiHeader--ios",{primary:"vkuiHeader--mode-primary",secondary:"vkuiHeader--mode-secondary",tertiary:"vkuiHeader--mode-tertiary"}[s],ce(d)&&"vkuiHeader--pi",N(u)&&"vkuiHeader--with-subtitle",k)}),a.createElement("div",{className:"vkuiHeader__main"},a.createElement(ye,{className:"vkuiHeader__content",Component:"span",mode:s,size:o},a.createElement("span",{className:l("vkuiHeader__content-in",v&&"vkuiHeader__content-in--multiline")},n),N(d)&&a.createElement(b,{className:"vkuiHeader__indicator",weight:"2"},d)),N(u)&&a.createElement(W,{className:"vkuiHeader__subtitle",Component:"span"},u)),N(c)&&a.createElement(w,{className:"vkuiHeader__aside",Component:"span"},c))},C,Ie=(C={none:"vkuiGroup--sizeX-none"},K(C,D.COMPACT,"vkuiGroup--sizeX-compact"),K(C,D.REGULAR,"vkuiGroup--sizeX-regular"),C),Ce=function(e){var i=e.header,s=e.description,r=e.children,o=e.separator,n=o===void 0?"auto":o,u=e.getRootRef,d=e.mode,c=e.padding,g=c===void 0?"m":c,v=e.className,k=e.tabIndex,m=I(e,["header","description","children","separator","getRootRef","mode","padding","className","tabIndex"]),h=a.useContext(me).isInsideModal,w=$(),P=ue(),z=P.sizeX,S=z===void 0?"none":z,f=d;d||(f=h?"plain":"none");var x=m.role==="tabpanel",B=x&&k===void 0?0:k,R=l("vkuiGroup__separator",n==="show"&&"vkuiGroup__separator--force");return a.createElement(a.Fragment,null,a.createElement("section",y(t({},m),{tabIndex:B,ref:u,className:l("vkuiInternalGroup","vkuiGroup",w===p.IOS&&"vkuiGroup--ios",Ie[S],f&&{none:l("vkuiGroup--mode-none","vkuiInternalGroup--mode-none"),plain:l("vkuiGroup--mode-plain","vkuiInternalGroup--mode-plain"),card:l("vkuiGroup--mode-card","vkuiInternalGroup--mode-card")}[f],{s:"vkuiGroup--padding-s",m:"vkuiGroup--padding-m"}[g],v)}),i,r,N(s)&&a.createElement(b,{className:"vkuiGroup__description"},s)),n!=="hide"&&a.createElement(a.Fragment,null,a.createElement(ge,{className:l(R,"vkuiGroup__separator--spacing"),size:16}),a.createElement(he,{className:l(R,"vkuiGroup__separator--separator")})))};const Z=L.div`
    background: linear-gradient(90deg, #bbb7f8 0%, #e4e5f7 97.08%);

    animation: wave 2s infinite ease-out;

    @media all and {
        min-width: 600px;
    }
     {
        background-size: 800px;

        @keyframes wave {
            0% {
                background-position: -400px 0;
            }
            100% {
                background-position: 400px 0;
            }
        }
    }

    @media all and {
        min-width: 1024px;
    }
     {
        background-size: 3000px;

        @keyframes wave {
            0% {
                background-position: -1500px 0;
            }
            100% {
                background-position: 1500px 0;
            }
        }
    }
`,Pe=({radius:e})=>q(we,{$width:e,$height:e}),we=L(Z)`
    height: ${({$height:e})=>`${e}px`};
    width: ${({$width:e})=>`${e+4}px`};
    border-radius: 50%;
`,Se=({width:e,height:i})=>q(Ee,{$width:e,$height:i}),Ee=L(Z)`
    height: ${({$height:e})=>`${e}`};
    width: ${({$width:e})=>`${e}`};
    border-radius: 4px;
`;export{Ce as G,Re as H,ke as I,Se as S,U as a,Be as b,Pe as c};
