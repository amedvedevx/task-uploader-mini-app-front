import{z as t,l as s,m as e,t as c,v as p,C as m,T as l,E as u,D as x}from"./index-8835db34.js";import{P as g,a as C,S as f,b as E}from"./Placeholder-df3a8a84.js";import{P as y,a as k,B as I,b as P}from"./App-ad7cf82c.js";import{H as _,D as v}from"./Div-9cadb232.js";import{S as i,L,a as S,G as T}from"./SkeletonRectangle-6126e663.js";import{I as w}from"./Image-a0fb7c0f.js";const G=()=>s(H,{children:[e(i,{width:"100%",height:"56px"}),e(i,{width:"100%",height:"56px"}),e(i,{width:"100%",height:"56px"})]}),H=t.div`
    display: flex;
    flex-direction: column;
    gap: 8px;
`,O=({collections:r})=>{const o=c.useRouter(),d=p();return e(A,{children:e(L,{children:r!=null&&r.length?r.slice(-3).map(({id:a,name:n,status:h})=>e(S,{after:h==="DONE"?e(b,{children:"завершен"}):e(D,{children:"открыт"}),subtitle:"Прислали ??",onClick:()=>{d(m(n)),o.pushPage(y,{collectionId:`${a}`})},children:n},a)):e(G,{})})})},D=t(l)`
    color: var(--vkui--color_text_positive);
`,b=t(l)`
    color: var(--vkui--color_text_secondary);
`,A=t.div`
    min-height: 190px;
`,q=()=>{const r=c.useRouter(),{data:o}=u({});return e(g,{id:k,children:s(N,{children:[e(C,{icon:e(z,{borderRadius:"s",withBorder:!1,src:x}),header:"Создавайте централизованный сбор файлов и документов",action:e(I,{stretched:!0,size:"m",onClick:()=>r.pushPage(P),children:"Создать"})}),s(R,{header:e(_,{mode:"primary",children:"История"}),mode:"plain",children:[e(f,{size:36,children:e(E,{})}),e(O,{collections:o==null?void 0:o.tasks})]})]})})},N=t(v)`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;
`,R=t(T)`
    max-width: 560px;
    width: 100%;
`,z=t(w)`
    width: 140px !important;
    height: 100px !important;
    background-color: transparent;
`;export{q as HomePage};
