import{r as s,_ as o,a as d,g as N,u as h,c as u,T as S,P as x,ad as b,b as w,ae as P,a7 as p,O as g}from"./index-fdc00ebf.js";import{g as $}from"./App-07f7a9a3.js";var E=["fixed"],C="data-tooltip-container",R=s.forwardRef(function(e,t){var i=e.fixed,n=i===void 0?!1:i,r=o(e,E);return r[C]=n?"fixed":"true",s.createElement("div",d({},r,{ref:t}))}),y=["centered","children","getRootRef","nav","className"],Y=function(e){var t=e.centered,i=t===void 0?!1:t,n=e.children,r=e.getRootRef;e.nav;var l=e.className,c=o(e,y),v=N(),m=h(),k=m.sizeX;return s.createElement("div",d({},c,{ref:r,className:u("vkuiPanel",$("vkuiPanel",k),i&&"vkuiPanel--centered",l)}),s.createElement(S,{Component:R,className:"vkuiPanel__in"},v===x.IOS&&s.createElement("div",{className:"vkuiPanel__fade"}),s.createElement("div",{className:"vkuiPanel__in-before"}),i?s.createElement("div",{className:"vkuiPanel__centered"},n):n,s.createElement("div",{className:"vkuiPanel__in-after"})))};function F(a){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:b(),t=arguments.length>2?arguments[2]:void 0,i="".concat(String(a),"--").concat(e);return t?t[i]:i}var z=["wide","className"],H=function(e){var t=e.wide,i=e.className,n=o(e,z);return s.createElement("div",d({},n,{"aria-hidden":!0,className:u("vkuiSeparator",!t&&"vkuiSeparator--padded",i),role:"separator"}),s.createElement("div",{className:"vkuiSeparator__in"}))},I=s.createContext({updateModalHeight:function(){},registerModal:function(){},isInsideModal:!1}),_=["size","style","className"],O=function(e){var t=e.size,i=t===void 0?8:t,n=e.style,r=e.className,l=o(e,_),c=w({height:i},n);return s.createElement("div",d({},l,{"aria-hidden":!0,className:u(r,"vkuiSpacing"),style:c}))},M=["className","children","weight","Component"],W=function(e){var t=e.className,i=e.children,n=e.weight,r=e.Component,l=r===void 0?"h5":r,c=o(e,M),v=h(),m=v.sizeY;return s.createElement(l,d({},c,{className:u(t,"vkuiSubhead",P("vkuiSubhead",m),n&&A["Subhead--weight-".concat(n)])}),i)},A={"Subhead--weight-1":"vkuiSubhead--weight-1","Subhead--weight-2":"vkuiSubhead--weight-2","Subhead--weight-3":"vkuiSubhead--weight-3"},T=["children","getRootRef","className"],q=function(e){var t=e.children,i=e.getRootRef,n=e.className,r=o(e,T);return s.createElement("div",d({},r,{ref:i,className:u("vkuiDiv",n)}),t)};const f=p.div`
    background: linear-gradient(90deg, #BBB7F8 0%, #E4E5F7 97.08%);

    animation: wave 2s infinite ease-out;

    @media all and {
        min-width: 600px;
    }
     {
        background-size: 800px;

        @keyframes wave {
            0% {
                background-position: -400px 0;
            }
            100% {
                background-position: 400px 0;
            }
        }
    }

    @media all and {
        min-width: 1024px;
    }
     {
        background-size: 3000px;

        @keyframes wave {
            0% {
                background-position: -1500px 0;
            }
            100% {
                background-position: 1500px 0;
            }
        }
    }
`,G=({radius:a})=>g(D,{$width:a,$height:a}),D=p(f)`
    height: ${({$height:a})=>`${a}px`};
    width: ${({$width:a})=>`${a+4}px`};
    border-radius: 50%;
`,J=({width:a,height:e})=>g(j,{$width:a,$height:e}),j=p(f)`
    height: ${({$height:a})=>`${a}`};
    width: ${({$width:a})=>`${a}`};
    border-radius: 4px;
`;export{q as D,I as M,Y as P,J as S,R as T,O as a,H as b,W as c,G as d,F as g};
