import{af as k,a7 as c,M as u,O as e,Z as M,$ as y,a5 as I,aE as S,r as E}from"./index-fdc00ebf.js";import{G as h,L as f,H as L,S as A}from"./List-d3e1bd39.js";import{A as g,c as x,b}from"./utils-53e99778.js";import{h as $,j as D}from"./App-07f7a9a3.js";import{a as O,I as P}from"./check_circle_on-bd688e91.js";import"./SkeletonRectangle-9ba514be.js";import{I as w}from"./PanelHeaderSkeleton-bbc1bd51.js";const H=k("Icon24DoneOutline","done_outline_24","0 0 24 24",'<symbol xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" id="done_outline_24"><path fill-rule="evenodd" d="M20.736 5.664a.9.9 0 0 1 0 1.272l-11.1 11.1a.9.9 0 0 1-1.272 0l-5.1-5.1a.9.9 0 0 1 1.272-1.272L9 16.127 19.464 5.664a.9.9 0 0 1 1.272 0Z" clip-rule="evenodd" /></symbol>',24,24,!1,void 0),j=({checked:l,onChange:r})=>u(B,{children:[e("input",{type:"checkbox",style:{display:"none"},checked:l,onChange:r}),l?e(O,{fill:"var(--vkui--color_accent_blue)"}):e(P,{fill:"var(--vkui--color_text_tertiary)"})]}),B=c.label`
    cursor: pointer;
    padding-right: 16px;
`;c.div`
    display: flex;
    flex-direction: column;
    padding: 115px 16px;
    gap: 8px;
`;c.div`
    display: flex;
    gap: 12px;
`;const C="https://vk.com/images/camera_100.png",J=({collection:l,invitedMembers:r,selection:d})=>{const n=M.useLocation(),p=y();return u(R,{children:[r&&(r==null?void 0:r.length)>0&&e(h,{separator:"hide",mode:"plain",padding:"s",children:e(f,{children:r.map(({vkUserId:a,firstName:i,lastName:s,fullName:t,photo:o})=>e(_,{before:e(g,{size:40,src:o===C?"#":o,alt:"icon",gradientColor:x(a),initials:b(`${i} ${s}`)}),after:e(H,{}),children:t},a))})}),l.length>0&&e(h,{mode:"plain",padding:"s",header:e(z,{color:"#6D7885",mode:"tertiary",children:"Выбранные участники"}),children:e(f,{children:l.map(({id:a,first_name:i,last_name:s,photo_100:t})=>e(_,{before:u(I,{children:[n.getPanelId()===$&&e(j,{checked:d.isMemberActive(a),onChange:o=>{d.handleSelectMember(o,a)}}),e(g,{size:40,src:t===C?"#":t,alt:"icon",gradientColor:x(a),initials:b(`${i} ${s}`)})]}),after:n.getPanelId()===D&&e(w,{fill:"var(--vkui--color_text_tertiary)",onClick:()=>p(S(a))}),onClick:o=>d.handleSelectMember(o,a),children:`${i} ${s}`},a))})})]})},R=c.div`
    padding-top: 103px;
    padding-bottom: 45px;
`,z=c(L)`
    .vkuiHeader__main {
        color: var(--vkui--color_text_subhead);
    }
`,_=c(A)`
    margin-bottom: 16px;
`,K=(l=[],r=[],d)=>{const[n,p]=E.useState(l),a=(t,o)=>{t.preventDefault(),t.stopPropagation(),p(m=>m.includes(o)?m.filter(v=>v!==o):[...m,o])},i=t=>n.includes(t),s=d.filter(t=>n.includes(t.id));return{selectedMembers:n,selectedCollection:s,handleSelectMember:a,isMemberActive:i}};export{J as M,K as u};
