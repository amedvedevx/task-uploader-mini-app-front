import{z as i,m as e,l as r,v as a,T as l,C as m,r as u,D as x,E as g}from"./index-9cf30789.js";import{P as k,a as f,S as w,b as E}from"./Placeholder-979c124e.js";import{P as C,a as b,B as O,b as v}from"./App-31b059fc.js";import{L as y,S as $,H as S,G as I}from"./List-546fa311.js";import{I as P}from"./Image-0ebfd64a.js";const c=i.div`
    background: linear-gradient(90deg, #BBB7F8 0%, #E4E5F7 97.08%);

    animation: wave 2s infinite ease-out;

    @media all and {
        min-width: 600px;
    }
     {
        background-size: 800px;

        @keyframes wave {
            0% {
                background-position: -400px 0;
            }
            100% {
                background-position: 400px 0;
            }
        }
    }

    @media all and {
        min-width: 1024px;
    }
     {
        background-size: 3000px;

        @keyframes wave {
            0% {
                background-position: -1500px 0;
            }
            100% {
                background-position: 1500px 0;
            }
        }
    }
`;i(c)`
    height: ${({$height:t})=>`${t}px`};
    width: ${({$width:t})=>`${t}px`};
    border-radius: 50%;
`;const n=({width:t,height:o})=>e(_,{$width:t,$height:o}),_=i(c)`
    height: ${({$height:t})=>`${t}`};
    width: ${({$width:t})=>`${t}`};
    border-radius: 4px;
`,L=()=>r(T,{children:[e(n,{width:"100%",height:"56px"}),e(n,{width:"100%",height:"56px"}),e(n,{width:"100%",height:"56px"})]}),T=i.div`
    display: flex;
    flex-direction: column;
    gap: 8px;
`,G=({collections:t})=>{const o=a.useRouter();return e(y,{children:t!=null&&t.length?t.slice(-3).map(({id:s,title:d,completion:p,isOpen:h})=>e($,{after:h?e(A,{children:"завершен"}):e(z,{children:"открыт"}),subtitle:`Прислали ${p}`,onClick:()=>o.pushPage(C,{collectionId:`${s}`}),children:d},s)):e(L,{})})},z=i(l)`
    color: var(--vkui--color_text_positive);
`,A=i(l)`
    color: var(--vkui--color_text_secondary);
`,B=[{id:1,title:"Документы в лагерь",isOpen:!1,completion:2},{id:2,title:"Справки",isOpen:!0,completion:21},{id:3,title:"Домашнее задание",isOpen:!0,completion:18},{id:4,title:"Документы в лагерь",isOpen:!1,completion:2},{id:5,title:"Справки",isOpen:!0,completion:21},{id:6,title:"Домашнее задание",isOpen:!0,completion:18}],Q=()=>{const t=a.useRouter(),o=m({});return u.useEffect(()=>{console.log(o)}),e(k,{id:b,children:r(H,{children:[e(f,{icon:e(D,{borderRadius:"s",withBorder:!1,src:x}),header:"Создавайте централизованный сбор файлов и документов",action:e(O,{stretched:!0,size:"m",onClick:()=>t.pushPage(v),children:"Создать"})}),r(R,{header:e(S,{mode:"primary",children:"История"}),mode:"plain",children:[e(w,{size:36,children:e(E,{})}),e(G,{collections:B})]})]})})},H=i(g)`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;
`,R=i(I)`
    max-width: 560px;
    width: 100%;
`,D=i(P)`
    width: 140px !important;
    height: 100px !important;
    background-color: transparent;
`;export{Q as HomePage};
