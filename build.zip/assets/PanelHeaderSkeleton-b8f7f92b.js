import{aj as E,g as u,m as w,a as c,P as _,c as o,r as a,k as v,az as g,ao as x,ar as M,aB as O,aq as R,ag as p,W as A}from"./index-d014d033.js";import{I,a as k,S}from"./SkeletonRectangle-8aad31fe.js";import{P as T}from"./ButtonGroup-037a4e07.js";const V=E("Icon12Circle","circle_12","0 0 12 12",'<symbol xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 12 12" id="circle_12"><path fill="currentColor" d="M10 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0z" /></symbol>',12,12,!1,void 0),Z=E("Icon12OnlineMobile","online_mobile_12","0 0 8 12",'<symbol xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 8 12" id="online_mobile_12"><path fill="currentColor" d="M5.99 0C7.1 0 8 .9 8 2.01v7.98C8 11.1 7.1 12 5.99 12H2.01C.9 12 0 11.1 0 9.99V2.01C0 .9.9 0 2.01 0h3.98Zm.007 3H2.004a.502.502 0 0 0-.503.502v4.995c0 .278.225.503.503.503h3.995a.502.502 0 0 0 .502-.502V3.503A.502.502 0 0 0 5.997 3Z" /></symbol>',8,12,!1,void 0);function N(e){return e<=36?12:e>36&&e<=48?16:e>48&&e<=64?20:N.MAX_SIZE}N.MAX_SIZE=24;var P={ios:"vkuiPanelHeaderContent--ios",android:"vkuiPanelHeaderContent--android",vkcom:"vkuiPanelHeaderContent--vkcom"},F=function(e){var t=e.hasStatus,r=e.hasBefore,n=e.children,i=w();return i===_.VKCOM?a.createElement(M,{Component:"div",weight:"2"},n):t||r?a.createElement(O,{Component:"div",weight:"2"},n):a.createElement("div",{className:"vkuiPanelHeaderContent__children-in"},n)},j=function(e){var t=e.className,r=e.style,n=e.aside,i=e.status,s=e.before,h=e.children,l=e.onClick,m=u(e,["className","style","aside","status","before","children","onClick"]),d=l?R:"div",C=l?{}:m,f=w(),B=l?c(o({},m),{onClick:l,activeEffectDelay:200,hasActive:f===_.IOS,activeMode:"opacity"}):{};return a.createElement("div",c(o({},C),{style:r,className:v("vkuiPanelHeaderContent",P.hasOwnProperty(f)?P[f]:P.android,t)}),g(s)&&a.createElement("div",{className:"vkuiPanelHeaderContent__before"},s),a.createElement(d,c(o({},B),{className:v("vkuiPanelHeaderContent__in",!s&&f!==_.ANDROID&&"vkuiPanelHeaderContent__in--centered")}),g(i)&&a.createElement(x,{className:"vkuiPanelHeaderContent__status"},i),a.createElement("div",{className:v("vkuiInternalPanelHeaderContent__children","vkuiPanelHeaderContent__children")},a.createElement(F,{hasStatus:g(i),hasBefore:g(s)},h),g(n)&&a.createElement("div",{className:"vkuiPanelHeaderContent__aside"},n)),g(s)&&a.createElement("div",{className:"vkuiPanelHeaderContent__width"})))},ee=function(e){var t=e.Component,r=t===void 0?"span":t,n=e.getRootRef,i=e.className,s=u(e,["Component","getRootRef","className"]);return a.createElement(r,c(o({},s),{className:v("vkuiVisuallyHidden",i),ref:n}))},L=function(e){var t=e.className,r=u(e,["className"]),n=a.useContext(I).size;return a.createElement(k.Badge,c(o({},r),{className:v("vkuiAvatarBadge",n<96&&"vkuiAvatarBadge--shifted",t)}))},W=function(e){var t=e.width,r=t===void 0?12:t,n=e.height,i=n===void 0?12:n,s=u(e,["width","height"]);return a.createElement(V,c(o({},s),{width:r>=24?15:12,height:i>=24?15:12}))},X=function(e){var t=e.width,r=t===void 0?8:t,n=e.height,i=n===void 0?12:n,s=u(e,["width","height"]);return a.createElement(Z,c(o({},s),{width:r>=24?9:8,height:i>=24?15:12}))},z=function(e){var t=e.preset,r=t===void 0?"online":t,n=e.className,i=u(e,["preset","className"]),s=a.useContext(I).size,h=N(s),l=r==="online",m=l?"vkuiAvatarBadge--preset-online":"vkuiAvatarBadge--preset-onlineMobile",d=l?W:X;return a.createElement(k.Badge,o({background:"stroke",className:v("vkuiAvatarBadge",m,n)},i),a.createElement(d,{width:h,height:h}))},y=30,H=96,D=y/H;function G(e){if(e<=16)return 5;if(e<=24)return 8;if(e<=32)return 10;if(e<=36)return 13;if(e<=44)return 14;if(e<=48)return 17;if(e<56)return 18;if(e<=64)return 21;if(e<=88)return 26;if(e<=H)return y;var t=Math.ceil(e*D),r=t%2;return t+r}var U=48,q={1:"red",2:"orange",3:"yellow",4:"green",5:"l-blue",6:"violet"},K={red:"vkuiAvatar--gradient-red",orange:"vkuiAvatar--gradient-orange",yellow:"vkuiAvatar--gradient-yellow",green:"vkuiAvatar--gradient-green",blue:"vkuiAvatar--gradient-blue","l-blue":"vkuiAvatar--gradient-l-blue",violet:"vkuiAvatar--gradient-violet"},b=function(e){var t=e.size,r=t===void 0?U:t,n=e.className,i=e.gradientColor,s=e.initials,h=e.fallbackIcon,l=e.children,m=u(e,["size","className","gradientColor","initials","fallbackIcon","children"]),d=typeof i=="number"?q[i]:i,C=d&&d!=="custom",f=s?void 0:h;return a.createElement(k,c(o({},m),{size:r,fallbackIcon:f,className:v("vkuiAvatar",d&&"vkuiAvatar--has-gradient",C&&K[d],n)}),s&&a.createElement("div",{className:"vkuiAvatar__initials",style:{fontSize:G(r)}},s),l)};b.Badge=L;b.BadgeWithPreset=z;b.Overlay=k.Overlay;p(T)`
    .vkuiPanelHeader__before {
        z-index: 1;
    }
    .vkuiPanelHeader__content {
        width: 100%;

        padding: 0px;

        position: absolute;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .vkuiPanelHeader__content-in {
        width: 70%;
        text-align: center;
    }
`;p(j)`
    padding: unset;
    .vkuiPanelHeaderContent__in {
        align-items: center;
    }
`;const te=()=>A(J,{children:A(S,{height:"37px",width:"50%"})}),J=p.div`
    display: flex;
    align-items: center;
    min-height: 52px;
`;export{b as A,j as P,ee as V,te as a};
