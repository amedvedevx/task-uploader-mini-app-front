import{a as f,u as b,r as n,e as h,f as _,z as k}from"./index-8835db34.js";import{P as w,a as p}from"./cancel-bd6bc49a.js";import{m as r,u as P,c as e,g as H}from"./App-ad7cf82c.js";const g=r("Icon28ArrowLeftOutline","arrow_left_outline_28","0 0 28 28",'<symbol viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" id="arrow_left_outline_28"><g fill="none" fill-rule="evenodd"><path d="M28 0H0v28h28z" /><path d="M12.293 6.293a1 1 0 0 1 1.414 1.414L8.414 13H22a1 1 0 0 1 .993.883L23 14a1 1 0 0 1-1 1H8.414l5.293 5.293a1 1 0 0 1 .083 1.32l-.083.094a1 1 0 0 1-1.414 0l-7-7-.073-.082A1.005 1.005 0 0 1 5 14l.004.09A1.006 1.006 0 0 1 5 14.02V14a1.02 1.02 0 0 1 .125-.484.878.878 0 0 1 .071-.111.999.999 0 0 1 .097-.112l-.08.09c.025-.031.051-.062.08-.09Z" fill="currentColor" fill-rule="nonzero" /></g></symbol>',28,28,!1,void 0),x=r("Icon28ChevronBack","chevron_back_28","0 0 20 28",'<symbol viewBox="0 0 20 28" xmlns="http://www.w3.org/2000/svg" id="chevron_back_28"><g fill="none" fill-rule="evenodd"><path d="M0 0h20v28H0z" /><path d="M4.56 12.94 13 4.5a1.414 1.414 0 0 1 2 2L7.5 14l7.5 7.5a1.414 1.414 0 0 1-2 2l-8.44-8.44a1.5 1.5 0 0 1 0-2.12Z" fill="currentColor" /></g></symbol>',20,28,!1,void 0),B=r("Icon28ChevronLeftOutline","chevron_left_outline_28","0 0 28 28",'<symbol fill="none" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" id="chevron_left_outline_28"><path d="m12.414 14 5.793-5.793a1 1 0 0 0-1.414-1.414l-6.5 6.5a1 1 0 0 0 0 1.414l6.5 6.5a1 1 0 0 0 1.414-1.414z" fill="currentColor" /></symbol>',28,28,!1,void 0);var C=["label","aria-label","className"],z=function(l){var o=l.label,i=l["aria-label"],c=i===void 0?"Назад":i,d=l.className,u=f(l,C),a=P(),v=b(),m=v.sizeX,s=a===e.VKCOM||a===e.IOS,t=n.createElement(g,null);switch(a){case e.IOS:t=n.createElement(x,null);break;case e.VKCOM:t=n.createElement(B,null);break}return n.createElement(w,h({},u,{className:_("vkuiPanelHeaderBack",H("vkuiPanelHeaderBack",m),a===e.IOS&&"vkuiPanelHeaderBack--ios",a===e.VKCOM&&"vkuiPanelHeaderBack--vkcom",s&&!!o&&"vkuiPanelHeaderBack--has-label",d),label:s&&o,"aria-label":c}),t)};const M=k(p)`
    .vkuiPanelHeader__before {
        z-index: 1;
    }
    .vkuiPanelHeader__content {
        width: 100%;

        padding: 0px;

        position: absolute;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .vkuiPanelHeader__content-in {
        width: 70%;
        text-align: center;
    }
`;export{M as P,z as a};
