import{ai as N,h as g,m as w,c,P,d,r as a,k as f,ay as m,an as x,aq as M,aA as O,ap as S,af as b,U as E}from"./index-2ae41d76.js";import{a as I,b as k,S as T}from"./SkeletonRectangle-042165fe.js";import{P as Z}from"./ButtonGroup-12b3d819.js";const F=N("Icon12Circle","circle_12","0 0 12 12",'<symbol xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 12 12" id="circle_12"><path fill="currentColor" d="M10 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0z" /></symbol>',12,12,!1,void 0),R=N("Icon12OnlineMobile","online_mobile_12","0 0 8 12",'<symbol xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 8 12" id="online_mobile_12"><path fill="currentColor" d="M5.99 0C7.1 0 8 .9 8 2.01v7.98C8 11.1 7.1 12 5.99 12H2.01C.9 12 0 11.1 0 9.99V2.01C0 .9.9 0 2.01 0h3.98Zm.007 3H2.004a.502.502 0 0 0-.503.502v4.995c0 .278.225.503.503.503h3.995a.502.502 0 0 0 .502-.502V3.503A.502.502 0 0 0 5.997 3Z" /></symbol>',8,12,!1,void 0);function A(e){return e<=36?12:e>36&&e<=48?16:e>48&&e<=64?20:A.MAX_SIZE}A.MAX_SIZE=24;var _={ios:"vkuiPanelHeaderContent--ios",android:"vkuiPanelHeaderContent--android",vkcom:"vkuiPanelHeaderContent--vkcom"},j=function(e){var t=e.hasStatus,r=e.hasBefore,n=e.children,i=w();return i===P.VKCOM?a.createElement(M,{Component:"div",weight:"2"},n):t||r?a.createElement(O,{Component:"div",weight:"2"},n):a.createElement("div",{className:"vkuiPanelHeaderContent__children-in"},n)},L=function(e){var t=e.className,r=e.style,n=e.aside,i=e.status,l=e.before,v=e.children,s=e.onClick,u=g(e,["className","style","aside","status","before","children","onClick"]),o=s?S:"div",C=s?{}:u,h=w(),B=s?c(d({},u),{onClick:s,activeEffectDelay:200,hasActive:h===P.IOS,activeMode:"opacity"}):{};return a.createElement("div",c(d({},C),{style:r,className:f("vkuiPanelHeaderContent",_.hasOwnProperty(h)?_[h]:_.android,t)}),m(l)&&a.createElement("div",{className:"vkuiPanelHeaderContent__before"},l),a.createElement(o,c(d({},B),{className:f("vkuiPanelHeaderContent__in",!l&&h!==P.ANDROID&&"vkuiPanelHeaderContent__in--centered")}),m(i)&&a.createElement(x,{className:"vkuiPanelHeaderContent__status"},i),a.createElement("div",{className:f("vkuiInternalPanelHeaderContent__children","vkuiPanelHeaderContent__children")},a.createElement(j,{hasStatus:m(i),hasBefore:m(l)},v),m(n)&&a.createElement("div",{className:"vkuiPanelHeaderContent__aside"},n)),m(l)&&a.createElement("div",{className:"vkuiPanelHeaderContent__width"})))},V=function(e){var t=e.className,r=g(e,["className"]),n=a.useContext(I).size;return a.createElement(k.Badge,c(d({},r),{className:f("vkuiAvatarBadge",n<96&&"vkuiAvatarBadge--shifted",t)}))},X=function(e){var t=e.width,r=t===void 0?12:t,n=e.height,i=n===void 0?12:n,l=g(e,["width","height"]);return a.createElement(F,c(d({},l),{width:r>=24?15:12,height:i>=24?15:12}))},D=function(e){var t=e.width,r=t===void 0?8:t,n=e.height,i=n===void 0?12:n,l=g(e,["width","height"]);return a.createElement(R,c(d({},l),{width:r>=24?9:8,height:i>=24?15:12}))},W=function(e){var t=e.preset,r=t===void 0?"online":t,n=e.className,i=g(e,["preset","className"]),l=a.useContext(I).size,v=A(l),s=r==="online",u=s?"vkuiAvatarBadge--preset-online":"vkuiAvatarBadge--preset-onlineMobile",o=s?X:D;return a.createElement(k.Badge,d({background:"stroke",className:f("vkuiAvatarBadge",u,n)},i),a.createElement(o,{width:v,height:v}))},y=30,H=96,z=y/H;function U(e){if(e<=16)return 5;if(e<=24)return 8;if(e<=32)return 10;if(e<=36)return 13;if(e<=44)return 14;if(e<=48)return 17;if(e<56)return 18;if(e<=64)return 21;if(e<=88)return 26;if(e<=H)return y;var t=Math.ceil(e*z),r=t%2;return t+r}var G=48,q={1:"red",2:"orange",3:"yellow",4:"green",5:"l-blue",6:"violet"},K={red:"vkuiAvatar--gradient-red",orange:"vkuiAvatar--gradient-orange",yellow:"vkuiAvatar--gradient-yellow",green:"vkuiAvatar--gradient-green",blue:"vkuiAvatar--gradient-blue","l-blue":"vkuiAvatar--gradient-l-blue",violet:"vkuiAvatar--gradient-violet"},p=function(e){var t=e.size,r=t===void 0?G:t,n=e.className,i=e.gradientColor,l=e.initials,v=e.fallbackIcon,s=e.children,u=g(e,["size","className","gradientColor","initials","fallbackIcon","children"]),o=typeof i=="number"?q[i]:i,C=o&&o!=="custom",h=l?void 0:v;return a.createElement(k,c(d({},u),{size:r,fallbackIcon:h,className:f("vkuiAvatar",o&&"vkuiAvatar--has-gradient",C&&K[o],n)}),l&&a.createElement("div",{className:"vkuiAvatar__initials",style:{fontSize:U(r)}},l),s)};p.Badge=V;p.BadgeWithPreset=W;p.Overlay=k.Overlay;function ee(e){return e%6+1}b(Z)`
    .vkuiPanelHeader__before {
        z-index: 1;
    }
    .vkuiPanelHeader__content {
        width: 100%;

        padding: 0px;

        position: absolute;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .vkuiPanelHeader__content-in {
        width: 70%;
        text-align: center;
    }
`;b(L)`
    padding: unset;
    .vkuiPanelHeaderContent__in {
        align-items: center;
    }
`;const te=()=>E(J,{children:E(T,{height:"37px",width:"50%"})}),J=b.div`
    display: flex;
    align-items: center;
    min-height: 52px;
`;export{p as A,L as P,te as a,ee as c};
