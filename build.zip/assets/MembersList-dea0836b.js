import{af as I,a7 as o,M as h,O as i,a5 as f,$ as v,aF as S,aG as w}from"./index-1b57d44e.js";import{G as u,L as $,H as z,S as A}from"./List-ccc2a60f.js";import{a as L,I as O}from"./check_circle_on-6effde56.js";import"./SkeletonRectangle-93c5c3ee.js";import{A as s,c as e,b as _}from"./utils-6cfda969.js";import{I as k}from"./PanelHeaderSkeleton-fbd5d74d.js";const H=I("Icon24DoneOutline","done_outline_24","0 0 24 24",'<symbol xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" id="done_outline_24"><path fill-rule="evenodd" d="M20.736 5.664a.9.9 0 0 1 0 1.272l-11.1 11.1a.9.9 0 0 1-1.272 0l-5.1-5.1a.9.9 0 0 1 1.272-1.272L9 16.127 19.464 5.664a.9.9 0 0 1 1.272 0Z" clip-rule="evenodd" /></symbol>',24,24,!1,void 0),m=({checked:d,onChange:r})=>h(b,{children:[i("input",{type:"checkbox",style:{display:"none"},checked:d,onChange:r}),d?i(L,{fill:"var(--vkui--color_accent_blue)"}):i(O,{fill:"var(--vkui--color_text_tertiary)"})]}),b=o.label`
    cursor: pointer;
    padding-right: 16px;
`;o.div`
    display: flex;
    flex-direction: column;
    padding: 115px 16px;
    gap: 8px;
`;o.div`
    display: flex;
    gap: 12px;
`;const B=({collection:d})=>i(u,{separator:"hide",mode:"plain",padding:"s",children:i($,{children:d==null?void 0:d.map(({vkUserId:r,firstName:n,lastName:a,fullName:t,photo:p})=>i(g,{before:i(s,{size:40,src:p===l?"#":p,alt:"icon",gradientColor:e(r),initials:_(`${n} ${a}`)}),after:i(H,{}),children:t},r))})}),D=({collection:d,selection:r})=>{const n=d==null?void 0:d.items.filter(a=>a.peer.type==="chat");return i(f,{children:(d==null?void 0:d.items.length)>0&&i(u,{mode:"plain",padding:"s",children:h($,{children:[(n==null?void 0:n.length)>0&&(n==null?void 0:n.map(a=>i(g,{before:h(f,{children:[i(m,{checked:Boolean(r==null?void 0:r.isChatActive(a)),onChange:t=>{r==null||r.handleSelectChat(t,a)}}),i(s,{size:40,src:a.chat_settings.photo?a.chat_settings.photo.photo_100:l,alt:"icon",gradientColor:e(a.peer.id)})]}),subtitle:`${a.chat_settings.members_count} участников`,onClick:t=>{r==null||r.handleSelectChat(t,a)},children:a.chat_settings.title},a.peer.id))),(d==null?void 0:d.profiles)&&d.profiles.map(a=>i(g,{before:h(f,{children:[i(m,{checked:Boolean(r==null?void 0:r.isMemberActive(a)),onChange:t=>{r==null||r.handleSelectMember(t,a)}}),i(s,{size:40,src:a.photo_100===l?"#":a.photo_100,alt:"icon",gradientColor:e(a.id),initials:_(`${a.first_name} ${a.last_name}`)})]}),onClick:t=>r==null?void 0:r.handleSelectMember(t,a),children:`${a.first_name} ${a.last_name}`},a.id))]})})})},G=({collection:d})=>{const r=v();return i(u,{mode:"plain",separator:"hide",padding:"s",header:i(y,{mode:"tertiary",children:"Выбранные участники"}),children:d==null?void 0:d.map(({id:n,first_name:a,last_name:t,photo_100:p})=>i(g,{before:i(s,{size:40,src:p===l?"#":p,alt:"icon",gradientColor:e(n),initials:_(`${a} ${t}`)}),after:i(k,{fill:"var(--vkui--color_text_tertiary)",onClick:()=>r(S(n))}),children:`${a} ${t}`},n))})},N=({collection:d})=>{const r=v();return i(f,{children:d==null?void 0:d.map(n=>{var a;return i(u,{mode:"plain",separator:"hide",padding:"s",header:i(y,{mode:"tertiary",children:n.chatName}),children:(a=n.members)==null?void 0:a.map(({id:t,photo_100:p,first_name:x,last_name:C})=>i(g,{before:i(s,{size:40,src:p===l?"#":p,alt:"icon",gradientColor:e(t),initials:_(`${x} ${C}`)}),after:i(k,{fill:"var(--vkui--color_text_tertiary)",onClick:()=>r(w(t))}),subtitle:`Из чата «${n.chatName}»`,children:`${x} ${C}`},t))},n.chatName)})})},l="https://vk.com/images/camera_100.png",J=({searchMembers:d,invitedMembers:r,selectedChatMembers:n,selectedMembers:a,selection:t})=>h(j,{children:[(r==null?void 0:r.length)>0&&i(B,{collection:r}),(d==null?void 0:d.items.length)>0&&i(D,{collection:d,selection:t}),(a==null?void 0:a.length)>0&&i(G,{collection:a}),(n==null?void 0:n.length)>0&&i(N,{collection:n})]}),j=o.div`
    padding-top: 103px;
    padding-bottom: 45px;
`,y=o(z)`
    .vkuiHeader__main {
        color: var(--vkui--color_text_subhead);
    }
`,g=o(A)`
    margin-bottom: 16px;
`;export{J as M};
