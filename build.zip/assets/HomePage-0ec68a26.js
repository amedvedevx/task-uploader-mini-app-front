import{z as t,l as n,m as e,t as c,T as l,C as m,D as u}from"./index-022aea65.js";import{S as a,P as x,a as g,b as f,c as _}from"./SkeletonRectangle-01fcb726.js";import{P as C,a as k,B as P,b as v}from"./App-4c3dd011.js";import{H as y}from"./Header-bdafe024.js";import{L as E,S as w,G as I}from"./List-e5761c2c.js";import{I as L}from"./Image-6f897e19.js";import{D as S}from"./Div-1a951607.js";const T=()=>n(G,{children:[e(a,{width:"100%",height:"56px"}),e(a,{width:"100%",height:"56px"}),e(a,{width:"100%",height:"56px"})]}),G=t.div`
    display: flex;
    flex-direction: column;
    gap: 8px;
`,O=({collections:i,isLoading:r})=>{const s=c.useRouter();return e(b,{children:e(E,{children:r?e(T,{}):i.map(({id:o,name:d,status:h,consolidatedData:p})=>e(w,{after:h==="DONE"?e(D,{children:"завершен"}):e(H,{children:"открыт"}),subtitle:`Прислали ${p.executedUsersCount}`,onClick:()=>{s.pushPage(C,{collectionId:o})},children:d},o))})})},H=t(l)`
    color: var(--vkui--color_text_positive);
`,D=t(l)`
    color: var(--vkui--color_text_secondary);
`,b=t.div`
    min-height: 190px;
`,q=()=>{const i=c.useRouter(),{data:r={tasks:[]},isLoading:s}=m({}),{tasks:o}=r;return e(x,{id:k,children:n(A,{children:[e(N,{icon:e(W,{borderRadius:"s",withBorder:!1,src:u}),header:"Создавайте централизованный сбор файлов и документов",action:e(P,{stretched:!0,size:"m",onClick:()=>i.pushPage(v),children:"Создать"})}),o&&n(R,{header:e(y,{mode:"primary",children:"История"}),mode:"plain",children:[e(g,{size:32,children:e(f,{})}),e(O,{collections:o,isLoading:s})]})]})})},A=t(S)`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;
`,N=t(_)`
    .vkuiPlaceholder__header {
        max-width: 372px;
    }
    .vkuiPlaceholder__in {
        display: flex;
        flex-direction: column;
        align-items: center;

        gap: 24px;
    }
    .vkuiPlaceholder__icon {
        margin: unset;
    }
    .vkuiPlaceholder__action:not(:first-child) {
        width: 100%;
        margin: unset;
    }
`,R=t(I)`
    max-width: 372px;
    width: 100%;
`,W=t(L)`
    width: 140px !important;
    height: 100px !important;
    background-color: transparent;
`;export{q as HomePage};
