import{_ as x,r as u,a as v,c as f,b as g,a7 as i,M as p,O as a,Z as _,aa as I,ab as C,W as P,a9 as E,ac as N}from"./index-1b57d44e.js";import{S as d,P as O,a as S,b as R,D as z}from"./SkeletonRectangle-93c5c3ee.js";import{I as L,a as m,L as T,S as w,H as B,G}from"./List-ccc2a60f.js";import{P as H,a as $,b as j}from"./App-5bd1ca1a.js";var A=["className"],W=function(t){var r=t.className,e=x(t,A),l=u.useContext(L),n=l.size;return u.createElement(m.Badge,v({},e,{className:f("vkuiImageBadge",n<96&&"vkuiImageBadge--shifted",r)}))},D=["size","borderRadius","style","className"],M=48,h=function(t){var r=t.size,e=r===void 0?M:r,l=t.borderRadius,n=l===void 0?"m":l,c=t.style,k=t.className,y=x(t,D),s;switch(n){case"s":{e<=32?s=2:e<=56&&(s=3),s=4;break}case"m":{e<=32?s=3:e<=48?s=4:e<=72?s=6:e<=80&&(s=8),s=10;break}case"l":e<=16?s=4:e<=20?s=5:e<=32?s=6:e<=40?s=8:e<=48?s=10:e<=56?s=12:e<=64&&(s=14),s=16}return u.createElement(m,v({},y,{size:e,style:g(g({},c),{},{borderRadius:s}),className:f("vkuiImage",k)}))};h.Badge=W;h.Overlay=m.Overlay;const U=()=>p(Z,{children:[a(d,{width:"100%",height:"56px"}),a(d,{width:"100%",height:"56px"}),a(d,{width:"100%",height:"56px"})]}),Z=i.div`
    display: flex;
    flex-direction: column;
    gap: 8px;
`,F=({collections:o,isLoading:t})=>{const r=_.useRouter();return a(J,{children:a(T,{children:t?a(U,{}):o.map(({id:e,name:l,status:n,consolidatedData:c})=>a(w,{after:n==="DONE"?a(q,{children:"завершен"}):a(Q,{children:"открыт"}),subtitle:`Прислали ${c.executedUsersCount}`,onClick:()=>{r.pushPage(H,{collectionId:e})},children:l},e))})})},Q=i(I)`
    color: var(--vkui--color_text_positive);
`,q=i(I)`
    color: var(--vkui--color_text_secondary);
`,J=i.div`
    min-height: 190px;
`,K=()=>{const o=_.useRouter(),{data:t={tasks:[]},isLoading:r}=C({}),{tasks:e}=t;return a(O,{id:$,children:p(V,{$isTasksExist:e.length>0,children:[a(b,{icon:a(Y,{borderRadius:"s",withBorder:!1,src:P}),header:"Создавайте централизованный сбор файлов и документов",action:a(E,{stretched:!0,size:"m",onClick:()=>o.pushPage(j),children:"Создать"})}),e.length>0&&p(X,{header:a(B,{mode:"primary",children:"История"}),mode:"plain",children:[a(S,{size:32,children:a(R,{})}),a(F,{collections:e,isLoading:r})]})]})})},V=i(z)`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;

    padding-top: ${({$isTasksExist:o})=>o?"12vh":"unset"};
`,b=i(N)`
    max-width: 372px;
    .vkuiPlaceholder__in {
        padding: 48px 0px;
    }
`,X=i(G)`
    max-width: 372px;
    width: 100%;
    .vkuiGroup__inner {
        padding: unset;
    }
`,Y=i(h)`
    width: 140px !important;
    height: 100px !important;
    background-color: transparent;
`,re=Object.freeze(Object.defineProperty({__proto__:null,HomePage:K,PlaceholderWidth:b},Symbol.toStringTag,{value:"Module"}));export{re as H,h as I,b as P};
