import{r as n,a as d,e as v,u as p,f as u,k as P,z as k,m as $}from"./index-022aea65.js";import{u as E,g as b,T as R,c as T,p as H,_ as y,h as m}from"./App-4c3dd011.js";var z=["fixed"],F="data-tooltip-container",_=n.forwardRef(function(e,t){var i=e.fixed,l=i===void 0?!1:i,o=d(e,z);return o[F]=l?"fixed":"true",n.createElement("div",v({},o,{ref:t}))}),M=["centered","children","getRootRef","nav","className"],U=function(e){var t=e.centered,i=t===void 0?!1:t,l=e.children,o=e.getRootRef;e.nav;var s=e.className,r=d(e,M),c=E(),h=p(),g=h.sizeX;return n.createElement("div",v({},r,{ref:o,className:u("vkuiPanel",b("vkuiPanel",g),i&&"vkuiPanel--centered",s)}),n.createElement(R,{Component:_,className:"vkuiPanel__in"},c===T.IOS&&n.createElement("div",{className:"vkuiPanel__fade"}),n.createElement("div",{className:"vkuiPanel__in-before"}),i?n.createElement("div",{className:"vkuiPanel__centered"},l):l,n.createElement("div",{className:"vkuiPanel__in-after"})))};function V(a){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:H(),t=arguments.length>2?arguments[2]:void 0,i="".concat(String(a),"--").concat(e);return t?t[i]:i}var A=["className","children","weight","level","Component"],Y=function(e){var t=e.className,i=e.children,l=e.weight,o=e.level,s=o===void 0?"1":o,r=e.Component,c=d(e,A);return r||(r="h"+s),n.createElement(r,v({},c,{className:u(t,"vkuiTitle",w["Title--level-".concat(s)],l&&w["Title--weight-".concat(l)])}),i)},w={"Title--level-1":"vkuiTitle--level-1","Title--level-2":"vkuiTitle--level-2","Title--level-3":"vkuiTitle--level-3","Title--weight-1":"vkuiTitle--weight-1","Title--weight-2":"vkuiTitle--weight-2","Title--weight-3":"vkuiTitle--weight-3"},j=["wide","className"],Z=function(e){var t=e.wide,i=e.className,l=d(e,j);return n.createElement("div",v({},l,{"aria-hidden":!0,className:u("vkuiSeparator",!t&&"vkuiSeparator--padded",i),role:"separator"}),n.createElement("div",{className:"vkuiSeparator__in"}))},ee=n.createContext({updateModalHeight:function(){},registerModal:function(){},isInsideModal:!1}),B=["size","style","className"],ae=function(e){var t=e.size,i=t===void 0?8:t,l=e.style,o=e.className,s=d(e,B),r=y({height:i},l);return n.createElement("div",v({},s,{"aria-hidden":!0,className:u(o,"vkuiSpacing"),style:r}))},X=["className","children","weight","caps","Component"],te=function(e){var t=e.className,i=e.children,l=e.weight,o=e.caps,s=e.Component,r=s===void 0?"span":s,c=d(e,X);return n.createElement(r,v({},c,{className:u(t,"vkuiFootnote",o&&"vkuiFootnote--caps",l&&I["Footnote--weight-".concat(l)])}),i)},I={"Footnote--weight-1":"vkuiFootnote--weight-1","Footnote--weight-2":"vkuiFootnote--weight-2","Footnote--weight-3":"vkuiFootnote--weight-3"},O=["className","children","weight","level","Component","getRootRef"],W=function(e){var t=e.className,i=e.children,l=e.weight,o=l===void 0?"3":l,s=e.level,r=s===void 0?"1":s,c=e.Component,h=c===void 0?"h4":c,g=e.getRootRef,S=d(e,O),f=p(),C=f.sizeY;return n.createElement(h,v({},S,{ref:g,className:u(t,"vkuiHeadline",P("vkuiHeadline",C),N["Headline--level-".concat(r)],N["Headline--weight-".concat(o)])}),i)},N={"Headline--level-1":"vkuiHeadline--level-1","Headline--level-2":"vkuiHeadline--level-2","Headline--weight-1":"vkuiHeadline--weight-1","Headline--weight-2":"vkuiHeadline--weight-2","Headline--weight-3":"vkuiHeadline--weight-3"},q=["className","children","weight","Component"],ie=function(e){var t=e.className,i=e.children,l=e.weight,o=e.Component,s=o===void 0?"h5":o,r=d(e,q),c=p(),h=c.sizeY;return n.createElement(s,v({},r,{className:u(t,"vkuiSubhead",P("vkuiSubhead",h),l&&D["Subhead--weight-".concat(l)])}),i)},D={"Subhead--weight-1":"vkuiSubhead--weight-1","Subhead--weight-2":"vkuiSubhead--weight-2","Subhead--weight-3":"vkuiSubhead--weight-3"},G=["icon","header","action","children","stretched","getRootRef","className"],le=function(e){var t=e.icon,i=e.header,l=e.action,o=e.children,s=e.stretched,r=e.getRootRef,c=e.className,h=d(e,G);return n.createElement("div",v({},h,{ref:r,className:u("vkuiPlaceholder",s&&"vkuiPlaceholder--stretched",c)}),n.createElement("div",{className:"vkuiPlaceholder__in"},m(t)&&n.createElement("div",{className:"vkuiPlaceholder__icon"},t),m(i)&&n.createElement(Y,{level:"2",weight:"2",className:"vkuiPlaceholder__header"},i),m(o)&&n.createElement(W,{weight:"3",className:"vkuiPlaceholder__text"},o),m(l)&&n.createElement("div",{className:"vkuiPlaceholder__action"},l)))};const x=k.div`
    background: linear-gradient(90deg, #BBB7F8 0%, #E4E5F7 97.08%);

    animation: wave 2s infinite ease-out;

    @media all and {
        min-width: 600px;
    }
     {
        background-size: 800px;

        @keyframes wave {
            0% {
                background-position: -400px 0;
            }
            100% {
                background-position: 400px 0;
            }
        }
    }

    @media all and {
        min-width: 1024px;
    }
     {
        background-size: 3000px;

        @keyframes wave {
            0% {
                background-position: -1500px 0;
            }
            100% {
                background-position: 1500px 0;
            }
        }
    }
`,ne=({radius:a})=>$(J,{$width:a,$height:a}),J=k(x)`
    height: ${({$height:a})=>`${a}px`};
    width: ${({$width:a})=>`${a}px`};
    border-radius: 50%;
`,oe=({width:a,height:e})=>$(K,{$width:a,$height:e}),K=k(x)`
    height: ${({$height:a})=>`${a}`};
    width: ${({$width:a})=>`${a}`};
    border-radius: 4px;
`;export{te as F,W as H,ee as M,U as P,oe as S,Y as T,ae as a,Z as b,le as c,ie as d,_ as e,ne as f,V as g};
