import{a as f,u as A,r as a,e as G,f as l,k as T,n as L,z as $,m as R}from"./index-8835db34.js";import{m as M,u as z,h as S,c as E,d as F,g as D,e as H}from"./App-ad7cf82c.js";import{g as O,c as X,H as y,M as Y,F as j,S as W,b as Z}from"./Placeholder-df3a8a84.js";const q=M("Icon24Chevron","chevron_24","0 0 16 24",'<symbol viewBox="0 0 16 24" xmlns="http://www.w3.org/2000/svg" id="chevron_24"><g fill="none" fill-rule="evenodd"><path d="M0 0h16v24H0z" /><path d="M4.706 7.706a1 1 0 0 1 0-1.412l.088-.088a.997.997 0 0 1 1.414.002l5.084 5.084a.998.998 0 0 1 0 1.416l-5.084 5.084a1.002 1.002 0 0 1-1.414.002l-.088-.088a.995.995 0 0 1 0-1.412L9 12 4.706 7.706Z" fill="currentColor" /></g></symbol>',16,24,!1,void 0);var J=["badgeBeforeTitle","badgeAfterTitle","badgeBeforeSubtitle","badgeAfterSubtitle","before","indicator","children","after","expandable","multiline","subhead","subtitle","extraSubtitle","className"],ie=function(e){var o=e.badgeBeforeTitle,i=e.badgeAfterTitle,n=e.badgeBeforeSubtitle,s=e.badgeAfterSubtitle,r=e.before,d=e.indicator,p=e.children,m=e.after,u=e.expandable,h=e.multiline,c=e.subhead,v=e.subtitle,k=e.extraSubtitle,x=e.className,C=f(e,J),g=z(),_=S(m)||u&&g===E.IOS,b=A(),N=b.sizeY;return a.createElement(F,G({},C,{className:l("vkuiSimpleCell",O("vkuiSimpleCell",g),T("vkuiSimpleCell",N),u&&"vkuiSimpleCell--exp",h&&"vkuiSimpleCell--mult",x)}),r,a.createElement("div",{className:"vkuiSimpleCell__main"},c&&a.createElement(X,{Component:"span",className:l("vkuiSimpleCell__text","vkuiSimpleCell__subhead")},c),a.createElement("div",{className:"vkuiSimpleCell__content"},o&&a.createElement("span",{className:"vkuiSimpleCell__badge"},o),a.createElement(y,{Component:"span",className:"vkuiSimpleCell__children",weight:"3"},p),S(i)&&a.createElement("span",{className:"vkuiSimpleCell__badge"},i)),v&&a.createElement("div",{className:"vkuiSimpleCell__content"},n&&a.createElement("span",{className:"vkuiSimpleCell__badge"},n),a.createElement("span",{className:l("vkuiSimpleCell__typography","vkuiSimpleCell__text","vkuiSimpleCell__subtitle")},v),s&&a.createElement("span",{className:"vkuiSimpleCell__badge"},s)),k&&a.createElement("span",{className:l("vkuiSimpleCell__typography","vkuiSimpleCell__text","vkuiSimpleCell__extraSubtitle")},k)),S(d)&&a.createElement(y,{Component:"span",weight:"3",className:"vkuiSimpleCell__indicator"},d),_&&a.createElement("div",{className:"vkuiSimpleCell__after"},m,u&&g===E.IOS&&a.createElement(q,null)))},K=["header","description","children","separator","getRootRef","mode","padding","className","tabIndex"],se=function(e){var o=e.header,i=e.description,n=e.children,s=e.separator,r=s===void 0?"auto":s,d=e.getRootRef,p=e.mode,m=e.padding,u=m===void 0?"m":m,h=e.className,c=e.tabIndex,v=f(e,K),k=a.useContext(Y),x=k.isInsideModal,C=z(),g=A(),_=g.sizeX,b=p;p||(b=x?"plain":"none");var N=v.role==="tabpanel",B=N&&c===void 0?0:c,w=l("vkuiGroup__separator",r==="show"&&"vkuiGroup__separator--force");return a.createElement("section",G({},v,{tabIndex:B,ref:d,className:l("vkuiGroup",C===E.IOS&&"vkuiGroup--ios",D("vkuiGroup",_),b&&I["Group--mode-".concat(b)],I["Group--padding-".concat(u)],h)}),a.createElement("div",{className:"vkuiGroup__inner"},o,n,S(i)&&a.createElement(j,{className:"vkuiGroup__description"},i)),r!=="hide"&&a.createElement(a.Fragment,null,a.createElement(W,{className:l(w,"vkuiGroup__separator--spacing"),size:16}),a.createElement(Z,{className:l(w,"vkuiGroup__separator--separator")})))},I={"Group--mode-plain":"vkuiGroup--mode-plain","Group--mode-none":"vkuiGroup--mode-none","Group--mode-card":"vkuiGroup--mode-card","Group--padding-s":"vkuiGroup--padding-s","Group--padding-m":"vkuiGroup--padding-m"},Q=a.createContext({toggleDrag:L}),U=["children","className"],re=function(e){var o=e.children,i=e.className,n=f(e,U),s=a.useState(!1),r=H(s,2),d=r[0],p=r[1];return a.createElement("div",G({role:"list"},n,{className:l("vkuiList",d&&"vkuiList--dragging",i)}),a.createElement(Q.Provider,{value:a.useMemo(function(){return{toggleDrag:p}},[])},o))};const P=$.div`
    background: linear-gradient(90deg, #BBB7F8 0%, #E4E5F7 97.08%);

    animation: wave 2s infinite ease-out;

    @media all and {
        min-width: 600px;
    }
     {
        background-size: 800px;

        @keyframes wave {
            0% {
                background-position: -400px 0;
            }
            100% {
                background-position: 400px 0;
            }
        }
    }

    @media all and {
        min-width: 1024px;
    }
     {
        background-size: 3000px;

        @keyframes wave {
            0% {
                background-position: -1500px 0;
            }
            100% {
                background-position: 1500px 0;
            }
        }
    }
`,oe=({radius:t})=>R(V,{$width:t,$height:t}),V=$(P)`
    height: ${({$height:t})=>`${t}px`};
    width: ${({$width:t})=>`${t}px`};
    border-radius: 50%;
`,ne=({width:t,height:e})=>R(ee,{$width:t,$height:e}),ee=$(P)`
    height: ${({$height:t})=>`${t}`};
    width: ${({$width:t})=>`${t}`};
    border-radius: 4px;
`;export{se as G,re as L,ne as S,ie as a,Q as b,oe as c};
